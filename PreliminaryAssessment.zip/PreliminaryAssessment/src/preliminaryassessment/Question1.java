/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package preliminaryassessment;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.regex.Pattern;
//import org.apache.commons.lang.StringEscapeUtils;

/**
 *
 * @author JP
 */
public class Question1 {

    /**
     * @param args the command line arguments
     */
    public static String[] mynumber;
    public static void main(String[] args) {
        Menu();
        //TestNumber();
        //Q2();//--]4--5--32--1
//        Q3();
           
//        String num="12**1**2**1";
//        
//        String[] temp1 = num.split("\\*\\*");
//         System.out.println(temp1.length);
//        System.out.println("temp1[0] = "+temp1[0]+" temp1[1] = "+temp1[1]);
//        String query = "hello+Search\\}query"
//          String jp = "j[k";
//          String patternStr = "i.e.";
//
//  
    }
    
    public static void Menu(){
        char quit = 'n';
        String input;
        int choice = 0;
        Scanner scan = new Scanner(System.in);
        
        while(quit != 'y'){
            System.out.println("Please choose a Question number below"
                +"\n1. For Question 1"
                +"\n2. For Question 2"
                +"\n3. For Question 3"
                );
            choice = scan.nextInt();
            
            switch(choice){
                case 1:
                    Q1();
                    break;
                case 2:
                    Q2();
                    break;
                case 3:
                    Q3();
                    break;
                default:
                    System.out.println("Please enter 1 or 2 or3 only");
            }
            System.out.println("Would you like to quit y/n");
            input = scan.next().toLowerCase();
            quit = input.charAt(0);
        }
    }
    
    public static void Q3(){
        System.out.println("Enter the Operator you want to use from below list"
            +"\n add FOR ADDITIONS"
            +"\n sub FOR SUBSTRACTION"
            +"\n mul FOR MULTIPLY"
            +"\n div FOR DIVIDE"
            +"\n sqt FOR SQUAR ROOT"
            );
        Scanner keyinput1 = new Scanner(System.in);
        String operator = keyinput1.next().toLowerCase();
        
        System.out.println("Enter the String of Number you want to use in format below"
            +"\n //[**]14**55*88*55 WHERE ** IS THE STRING SEPERATOR");
        Scanner keyinput = new Scanner(System.in);
        String num = keyinput.next();
        
        String[] temp1 = num.split("//\\[");
        System.out.println("temp1[1] = "+temp1[1]);
        String[] temp2 = temp1[1].split("\\]");
        System.out.println("temp2[0] = "+ temp2[0]+" temp2[1] = "+temp2[1]);
        if("**".equals(temp2[0]))
            mynumber = temp2[1].split("\\*\\*");
        else
            mynumber = temp2[1].split("\\"+temp2[0]+"");
        System.out.println("This length"+mynumber.length);
        switch(operator){
            case "add":
                Add();
                break;
            case "sub": 
                Substract();
                break;
            case "div": 
                Divide();
                break;
            case "mul": 
                Multiply();
                break;
            case "sqt": 
                Sqroot();
                break;
            default: System.out.println("No such operator : " + operator);//default: throw new RuntimeException("No such operator : " + operator);
        }
        for(int i=0 ; i < mynumber.length; i++ ){
            System.out.println("index "+i+" = "+mynumber[i]);
        }
        
        
        
//        int i = Integer.parseInt(num);
//        int sum=i+10;
//        System.out.println(sum);
    }
    public static void Sqroot(){
        int sum=0;
        double root[] = new double[mynumber.length];//new int[num];
        

        
        for(int i=0; i<+mynumber.length; i++){
            int temp1 = Integer.parseInt(mynumber[i]);
            double temp = Double.parseDouble(mynumber[i]);
            root[i] = Math.sqrt(temp);
        }
        System.out.print("My number lenght"+mynumber.length+" My root"+root.length);
        for(int i=0; i<+mynumber.length; i++){
            System.out.print(" Squar root of "+mynumber[i]+" = "+root[i]);
        }
    }
    public static void Add(){
        int sum=0;
        for(int i=0; i<+mynumber.length; i++){
            int temp = Integer.parseInt(mynumber[i]);
            sum = sum+temp;
        }
        System.out.println("Sum = "+sum);
    }
     public static void Substract(){
        int difference = 0;
        for(int i=0; i<+mynumber.length; i++){
            if(i == 0)
                difference = Integer.parseInt(mynumber[i]);
            else{
                difference =  difference - Integer.parseInt(mynumber[i]);
            }
        }
        System.out.println("difference = "+difference);
    }
    public static void Divide(){
        double quotiant = 0,dividant =1;
        for(int i=0; i<+mynumber.length; i++){
            if(i == 0)
                quotiant = Integer.parseInt(mynumber[i]);
            else{
                quotiant =  quotiant / Integer.parseInt(mynumber[i]);
            }
        }
        System.out.println("quotiant = "+quotiant);
    }
    public static void Multiply(){
        double product = 1;
        for(int i=0; i<+mynumber.length; i++){
            product =  product * Integer.parseInt(mynumber[i]);
        }
        System.out.println("product = "+product);
    }
    
    public static void Q1(){
        int sum = 0;
        boolean sumk = false;
        System.out.println("Enter the lenght of your list");
        Scanner keyinput = new Scanner(System.in);
        int num = keyinput.nextInt();
        
        System.out.println("Enter the value of sum (K)");
        Scanner keyinput2 = new Scanner(System.in);
        int k = keyinput2.nextInt();
               
        ArrayList<Integer> list = new ArrayList<>();
        for(int i=0; i<num;i++){
            System.out.println("Add item "+(i+1)+" to the List");
            list.add(keyinput.nextInt());
        }
            
        ListIterator<Integer> iterator1 = list.listIterator();
        while(iterator1.hasNext()){
            int firstnum = iterator1.next();
            ListIterator<Integer> iterator2 = list.listIterator();
            
            while(iterator2.hasNext()){
                int i = iterator2.next();
                if(list.indexOf(i)!= list.lastIndexOf(firstnum)){
                    sum = firstnum +i; 
                    if(sum == k){
                     System.out.println(firstnum+" + "+i+" = "+sum);
                     for(int j=list.indexOf(i)+1; j<list.size(); j++)
                        iterator2.next(); 
                     sumk = true;
                     break;
                    }
                }
            }
            if(sumk == true)
                break;
        }
        if(sumk == false)
            System.out.println("There is no combination which adds up to "+k);
             
    }
    
    public static void Q2(){
        int arrayN[],prod[];
        int keyIn;
        System.out.println("Enter the lenght of your Array");
        Scanner keyinput = new Scanner(System.in);
        int num = keyinput.nextInt();
        arrayN = new int[num];
        prod = new int[num];
        for(int i=0; i<num;i++){
            System.out.println("===Enter item "+(i+1));
            keyIn = keyinput.nextInt();
            arrayN[i] = keyIn;
        }
        System.out.print("Your array is { ");
        for(int j=0; j<arrayN.length; j++){
            if(arrayN.length-1 == j)
                System.out.print(arrayN[j]);
            else
                System.out.print(arrayN[j]+", ");
        }
        System.out.println(" }");
        
        for(int i=0; i<prod.length; i++){
            int pro=1;
            for(int j=0; j<prod.length; j++){
                if(i!=j){
                    pro = pro * arrayN[j];
                }
            }
            prod[i]=pro;
            pro=0;
        }
        
        System.out.print("Your Product array is { ");
        for(int j=0; j<arrayN.length; j++){
            if(arrayN.length-1 == j)
                System.out.print(prod[j]);
            else
                System.out.print(prod[j]+", ");
        }
        System.out.println(" }");
        
    }
    
    

   
    
    
    
    
    
}
